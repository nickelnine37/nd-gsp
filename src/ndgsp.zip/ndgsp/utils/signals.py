from typing import Tuple
import numpy as np
from ndgsp.utils.types import Signal
import jax.numpy as jnp
import pandas as pd



